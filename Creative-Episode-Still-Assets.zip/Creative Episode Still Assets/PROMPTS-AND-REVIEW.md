# Creative Episode still assets

Generated using the built-in image generator, one scene per call. Original references preserved. White backgrounds retained as requested. All 11 outputs contain no extra words, people, hands, or office photograph backgrounds. Text spelling is correct; no second passes were made.

Review flags: lightbulb.png has seven rays rather than eight; empty-wall-mark.png carries the same seven-ray bulb. The flowers have visible paper relief/shading beyond the flat preamble. Exact hex colors and pure white pixels are not guaranteed by image generation.

## creative-episode-wordmark.png

Flat graphic asset for a private office tool, matched to an existing headquarters identity. Indigo #2E3A8C, periwinkle #5B63B8, signal yellow #EFE52B, paper white #F4F2EE, felt black #16161C. Notes are cyan-blue, pastel pink, lime green, and yellow. Crisp edges, even light, no photographic room, no people, no hands, no shadows cast on a wall, no mockup, no browser, no device frame, no watermark, no extra words. Isolated on a pure white background so the graphic can be cut out. Not 3D, not clay, not isometric, not a diorama, not a UI screenshot.

Only the two words Creative and Episode. Creative is on top, electric blue #2F5BFF, rounded outline lettering like a neon tube with no glow and no bloom. Episode sits below, offset slightly right, signal yellow #EFE52B, same tube construction. Flat, front-facing, generous margin, pure white background. No other words. No underline. No lightbulb.

## good-ideas-start-here.png

Flat graphic asset for a private office tool, matched to an existing headquarters identity. Indigo #2E3A8C, periwinkle #5B63B8, signal yellow #EFE52B, paper white #F4F2EE, felt black #16161C. Notes are cyan-blue, pastel pink, lime green, and yellow. Crisp edges, even light, no photographic room, no people, no hands, no shadows cast on a wall, no mockup, no browser, no device frame, no watermark, no extra words. Isolated on a pure white background so the graphic can be cut out. Not 3D, not clay, not isometric, not a diorama, not a UI screenshot.

Only four stacked lines of black informal handwriting, mixed case, narrow and slightly uneven, as if written with a marker on a wall: Good / Ideas / Start / Here. Front-facing, centered as a block, generous margin, pure white background. No neon, no lightbulb, no paper, no box.

## lightbulb.png

Flat graphic asset for a private office tool, matched to an existing headquarters identity. Indigo #2E3A8C, periwinkle #5B63B8, signal yellow #EFE52B, paper white #F4F2EE, felt black #16161C. Notes are cyan-blue, pastel pink, lime green, and yellow. Crisp edges, even light, no photographic room, no people, no hands, no shadows cast on a wall, no mockup, no browser, no device frame, no watermark, no extra words. Isolated on a pure white background so the graphic can be cut out. Not 3D, not clay, not isometric, not a diorama, not a UI screenshot.

One yellow line-icon of a lightbulb, signal yellow #EFE52B, even stroke. Round bulb, screw base of three horizontal bands, two filament loops, eight short rounded dashes around the bulb. Flat, no glow, no gradient, no shading, pure white background, generous margin. No text.

## note-blue.png

Flat graphic asset for a private office tool, matched to an existing headquarters identity. Indigo #2E3A8C, periwinkle #5B63B8, signal yellow #EFE52B, paper white #F4F2EE, felt black #16161C. Notes are cyan-blue, pastel pink, lime green, and yellow. Crisp edges, even light, no photographic room, no people, no hands, no shadows cast on a wall, no mockup, no browser, no device frame, no watermark, no extra words. Isolated on a pure white background so the graphic can be cut out. Not 3D, not clay, not isometric, not a diorama, not a UI screenshot.

One blank square sticky note, rotated about 3 degrees. Paper color: cyan-blue #7EC8E3. Soft folded corner at the bottom right, a faint paper grain, no handwriting, no lines, no pin, no tape, no shadow on a wall. Isolated on pure white. Square composition, the note filling most of the frame with an even margin.

## note-pink.png

Flat graphic asset for a private office tool, matched to an existing headquarters identity. Indigo #2E3A8C, periwinkle #5B63B8, signal yellow #EFE52B, paper white #F4F2EE, felt black #16161C. Notes are cyan-blue, pastel pink, lime green, and yellow. Crisp edges, even light, no photographic room, no people, no hands, no shadows cast on a wall, no mockup, no browser, no device frame, no watermark, no extra words. Isolated on a pure white background so the graphic can be cut out. Not 3D, not clay, not isometric, not a diorama, not a UI screenshot.

One blank square sticky note, rotated about 3 degrees. Paper color: pastel pink #F4A7C3. Soft folded corner at the bottom right, a faint paper grain, no handwriting, no lines, no pin, no tape, no shadow on a wall. Isolated on pure white. Square composition, the note filling most of the frame with an even margin.

## note-green.png

Flat graphic asset for a private office tool, matched to an existing headquarters identity. Indigo #2E3A8C, periwinkle #5B63B8, signal yellow #EFE52B, paper white #F4F2EE, felt black #16161C. Notes are cyan-blue, pastel pink, lime green, and yellow. Crisp edges, even light, no photographic room, no people, no hands, no shadows cast on a wall, no mockup, no browser, no device frame, no watermark, no extra words. Isolated on a pure white background so the graphic can be cut out. Not 3D, not clay, not isometric, not a diorama, not a UI screenshot.

One blank square sticky note, rotated about 3 degrees. Paper color: lime green #C5E87A. Soft folded corner at the bottom right, a faint paper grain, no handwriting, no lines, no pin, no tape, no shadow on a wall. Isolated on pure white. Square composition, the note filling most of the frame with an even margin.

## note-yellow.png

Flat graphic asset for a private office tool, matched to an existing headquarters identity. Indigo #2E3A8C, periwinkle #5B63B8, signal yellow #EFE52B, paper white #F4F2EE, felt black #16161C. Notes are cyan-blue, pastel pink, lime green, and yellow. Crisp edges, even light, no photographic room, no people, no hands, no shadows cast on a wall, no mockup, no browser, no device frame, no watermark, no extra words. Isolated on a pure white background so the graphic can be cut out. Not 3D, not clay, not isometric, not a diorama, not a UI screenshot.

One blank square sticky note, rotated about 3 degrees. Paper color: yellow #FFE56B. Soft folded corner at the bottom right, a faint paper grain, no handwriting, no lines, no pin, no tape, no shadow on a wall. Isolated on pure white. Square composition, the note filling most of the frame with an even margin.

## felt-board-empty.png

Flat graphic asset for a private office tool, matched to an existing headquarters identity. Indigo #2E3A8C, periwinkle #5B63B8, signal yellow #EFE52B, paper white #F4F2EE, felt black #16161C. Notes are cyan-blue, pastel pink, lime green, and yellow. Crisp edges, even light, no photographic room, no people, no hands, no shadows cast on a wall, no mockup, no browser, no device frame, no watermark, no extra words. Isolated on a pure white background so the graphic can be cut out. Not 3D, not clay, not isometric, not a diorama, not a UI screenshot.

A wide empty display board shaped like a soft horizontal bottle: long rounded rectangle on the left flowing into a wider rounded end on the right. Fill is felt black #16161C. A thin even gold line #E8B23A traces the inner edge, with no glow. No notes, no shirt, no flowers, no text, no hanger. Isolated on pure white. Landscape frame, 16:9.

## paper-flower-white.png

Flat graphic asset for a private office tool, matched to an existing headquarters identity. Indigo #2E3A8C, periwinkle #5B63B8, signal yellow #EFE52B, paper white #F4F2EE, felt black #16161C. Notes are cyan-blue, pastel pink, lime green, and yellow. Crisp edges, even light, no photographic room, no people, no hands, no shadows cast on a wall, no mockup, no browser, no device frame, no watermark, no extra words. Isolated on a pure white background so the graphic can be cut out. Not 3D, not clay, not isometric, not a diorama, not a UI screenshot.

One paper flower, front-facing, layered rounded petals, small faceted center. White petals, blue-gray center. No stem, no leaves, no text, no shadow outside the flower. Pure white background.

## paper-flower-gold.png

Flat graphic asset for a private office tool, matched to an existing headquarters identity. Indigo #2E3A8C, periwinkle #5B63B8, signal yellow #EFE52B, paper white #F4F2EE, felt black #16161C. Notes are cyan-blue, pastel pink, lime green, and yellow. Crisp edges, even light, no photographic room, no people, no hands, no shadows cast on a wall, no mockup, no browser, no device frame, no watermark, no extra words. Isolated on a pure white background so the graphic can be cut out. Not 3D, not clay, not isometric, not a diorama, not a UI screenshot.

One paper flower, front-facing, layered rounded petals, small faceted center. Golden yellow petals #E8B23A, pale center. No stem, no leaves, no text, no shadow outside the flower. Pure white background.

## empty-wall-mark.png

Flat graphic asset for a private office tool, matched to an existing headquarters identity. Indigo #2E3A8C, periwinkle #5B63B8, signal yellow #EFE52B, paper white #F4F2EE, felt black #16161C. Notes are cyan-blue, pastel pink, lime green, and yellow. Crisp edges, even light, no photographic room, no people, no hands, no shadows cast on a wall, no mockup, no browser, no device frame, no watermark, no extra words. Isolated on a pure white background so the graphic can be cut out. Not 3D, not clay, not isometric, not a diorama, not a UI screenshot.

A small cluster for an empty wall: the yellow lightbulb from scene 3, drawn smaller, sitting above a single blank yellow sticky note. Lots of pure white around the cluster. No words. No people. No room.
